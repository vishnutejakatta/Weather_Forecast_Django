from django.apps import AppConfig


class HomesiteConfig(AppConfig):
    name = 'HomeSite'
