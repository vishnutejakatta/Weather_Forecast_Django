from django.apps import AppConfig


class CityConfig(AppConfig):
    name = 'City'
