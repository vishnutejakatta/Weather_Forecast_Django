from django.apps import AppConfig


class ZipcodeConfig(AppConfig):
    name = 'ZipCode'
